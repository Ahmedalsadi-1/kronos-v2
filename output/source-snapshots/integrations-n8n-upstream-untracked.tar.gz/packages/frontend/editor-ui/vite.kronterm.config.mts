import { mergeConfig, defineConfig } from 'vite';
import original from './vite.config.mts';
import {resolve} from 'node:path';
export default mergeConfig(original, defineConfig({
 base:'./',
 define:{'process.env.NODE_ENV':JSON.stringify('production'),'process.env':{}},
 resolve:{alias:[{find:/^@vue-flow\/core$/,replacement:resolve('src/kronterm-vue-flow-core.mjs')},{find:/^axios$/,replacement:resolve('src/kronterm-native-axios.ts')},{find:/^axios-native$/,replacement:resolve('node_modules/axios/index.js')}]},
 build:{outDir:resolve('../../../../../../public/workflow-native'),emptyOutDir:true,cssCodeSplit:false,
 lib:{entry:resolve('src/kronterm-native.ts'),formats:['es'],fileName:()=> 'editor.js',cssFileName:'editor'},
 rolldownOptions:{output:{codeSplitting:undefined}},
 },
}));